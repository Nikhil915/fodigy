const express = require("express");
const mongoose = require("mongoose");


const router = express.Router();
const DietModel = mongoose.model("Diet");

router.get("/list",  (req, res) =>{

    //Setting
    // var diet = new DietModel();
    // diet.id = "1";
    // diet.save();

    // Getting
    DietModel.find((err, docs) =>{
        if(!err)
        {
            console.log(docs);
            res.render("list", {data : docs})
        }
        else {
            res.send("Diet Controller")
        }
    });
    
});


module.exports = router;