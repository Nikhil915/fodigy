# Mongodb database migration on top of nodejs and express js


## Now our migration script will modify 'Full Name' as name or 'Last Name';
migration script will load from migration folder. For this we need migrate-mongo.

    npm install -g migrate-mongo

Initialize a  migrate-mongo project and configure db
migrate-mongo init

#### now create migration script:
            migrate-mongo create modify-fullname-as-name 
            


# Run migration up and down check status

    migrate-mongo up 
    migrate-mongo status
    migrate-mongo down

# API's
# post : http://localhost:4000/user/signup
{
    "username" : "N",
    "email" : "a1@gmail.com",
    "password" : "123456"
}

=>
# YOU'LL GET A TOKEN
 {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoiNWZlZjA4ZGVlNjNmN2YwYjFjMjI0NDAwIn0sImlhdCI6MTYwOTUwMDg5NCwiZXhwIjoxNjA5NTEwODk0fQ.1E08hMD084sQKWZAvKhKtSVQrCvKK3KL_zoAquK-2lQ"
}


# post:  http://localhost:4000/user/login

{
    "email" : "a1@gmail.com",
    "password" : "123456"
}


Response : {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoiNWZlZjA4ZGVlNjNmN2YwYjFjMjI0NDAwIn0sImlhdCI6MTYwOTUwMTA1NCwiZXhwIjoxNjA5NTA0NjU0fQ.OTtYvlLYqm-n-1n8-mf631FrmD8tGUfha8A3_a9TTbg"
}


# GET : http://localhost:4000/foodsearches

# POST : http://localhost:4000/foodsearches

# GET : http://localhost:4000/user/me

# GET : http://localhost:4000/foodgets

# POST : http://localhost:4000/foodgets

# GET : http://localhost:4000/dietplans

# POST : http://localhost:4000/dietplans