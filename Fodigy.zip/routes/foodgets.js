const express = require('express')
const router = express.Router()
const Foodget = require('../model/foodget')


router.get('/', async(req,res) => {
    try{
           const foodgets = await Foodget.find()
           res.json(foodgets)
    }catch(err){
        res.send('Error ' + err)
    }
})

router.get('/:id', async(req,res) => {
    try{
           const foodgets = await Foodget.findById(req.params.id)
           res.json(foodgets)
    }catch(err){
        res.send('Error ' + err)
    }
})


router.post('/', async(req,res) => {
    const foodgets = new Foodget({
        food_id: req.body.food_id,
        food_name: req.body.food_name,
        food_type: req.body.food_type,
        brand_name: req.body.brand_name,
        food_url: req.body.food_url,
        serving_id: req.body.serving_id,
        serving_description: req.body.serving_description,
        serving_url: req.body.serving_url,
        metric_serving_amount: req.body.metric_serving_amount,
        metric_serving_unit: req.body.metric_serving_unit,
        number_of_units: req.body.number_of_units,
        measurement_description: req.body.measurement_description,
        calories: req.body.calories,
        carbohydrate: req.body.carbohydrate,
        protein: req.body.protein,
        fat: req.body.fat,
        saturated_fat: req.body.saturated_fat,
        polyunsaturated_fat: req.body.polyunsaturated_fat,
        monounsaturated_fat: req.body.monounsaturated_fat,
        trans_fat: req.body.trans_fat,
        cholesterol: req.body.cholesterol,
        sodium: req.body.sodium,
        potassium: req.body.potassium,
        fiber: req.body.fiber,
        sugar: req.body.sugar,
        vitamin_a: req.body.vitamin_a,
        vitamin_c: req.body.vitamin_c,
        calcium: req.body.calcium,
        iron: req.body.iron,
    })

    try{
        const a1 =  await foodgets.save() 
        res.json(a1)
    }catch(err){
        res.send('Error')
    }
})

router.patch('/:id',async(req,res)=> {
    try{
        const foodgets = await Foodget.findById(req.params.id) 
        foodgets.sub = req.body.sub
        const a1 = await foodgets.save()
        res.json(a1)   
    }catch(err){
        res.send('Error')
    }

})

module.exports = router