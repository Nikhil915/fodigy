const express = require('express')
const router = express.Router()
const Dietplans = require('../model/dietplans')


router.get('/', async(req,res) => {
    try{
           const dietplans = await Dietplans.find()
           res.json(Dietplans)
    }catch(err){
        res.send('Error ' + err)
    }
})

router.get('/:id', async(req,res) => {
    try{
           const dietplans = await Dietplans.findById(req.params.id)
           res.json(Dietplans)
    }catch(err){
        res.send('Error ' + err)
    }
})


router.post('/', async(req,res) => {
    const dietplans = new Dietplans({
        id: req.body.id,
        title: req.body.title,
        plan_type: req.body.plan_type,
        energy_required_for_man: req.body.energy_required_for_man,
        energy_required_for_women: req.body.energy_required_for_women,
        energy_burn_goal: req.body.energy_burn_goal,
        description: req.body.description,
        protein: req.body.protein,
        carbohydrate: req.body.carbohydrate,
        fat: req.body.fat,
        created_by: req.body.created_by,
        updated_by: req.body.updated_by,
        deleted_by: req.body.deleted_by,
        is_active: req.body.is_active,
        is_deleted: req.body.is_deleted,
        created_on: req.body.created_on,
        updated_on: req.body.updated_on,
        deleted_on: req.body.deleted_on
    })

    try{
        const a1 =  await dietplans.save() 
        res.json(a1)
    }catch(err){
        res.send('Error')
    }
})

router.patch('/:id',async(req,res)=> {
    try{
        const dietplans = await Dietplans.findById(req.params.id) 
        dietplans.sub = req.body.sub
        const a1 = await dietplans.save()
        res.json(a1)   
    }catch(err){
        res.send('Error')
    }

})

module.exports = router;