const express = require("express");
const { check, validationResult } = require("express-validator/check");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const router = express.Router();

//import model
const foodsearch = require("../model/foodsearch");

const app = express();

//foodsearch
router.post(
    "/food/search",
    [
      check("foodid", "Please enter a valid ID"),
      check("foodname", "Please enter a valid foodname"),
      check("foodtype"),
      check("brandname"),
      check("foodurl"),
      check("fooddescription"),
    ],
    async (req, res) => {
      const errors = validationResult(req);
  
      if (!errors.isfoodid()) {
        return res.status(400).json({
          errors: errors.array()
        });
      }
  
      const {  foodid } = req.body;
      try {
        let foodid = await Food.findOne({
          foodid
        });
        if (!user)
          return res.status(400).json({
            message: ""
          });
  
        const isMatch = await bcrypt.compare(foodtype, food.foodtype);
        if (!isMatch)
          return res.status(400).json({
            message: ""
          });
          
          const isFood = await bcrypt.compare(brandname, foodurl, food.fooddescription);
          if (!isFood)
          return res.status(400).json({
              message : ""
          })
        const payload = {
          food: {
            id: food.id
          }
        };
  
        jwt.sign(
          payload,
          "randomString",
          {
            expiresIn: 3600
          },
          (err, token) => {
            if (err) throw err;
            res.status(200).json({
              token
            });
          }
        );
      } catch (e) {
        console.error(e);
        res.status(500).json({
          message: "Server Error"
        });
      }
    }
  );


//food barcode
app.param(":id", function(req, res, next, collection) {
	req.collection = db.get(collection, {safe: true});
	next();
});

app.get('/food/barcode', function(req, res, next) {
  req.collection.find({}, {
    limit: 20
    // ,	fields: { searchResults: 1 }
  }).then(function(docs) {
    res.send(docs);
  })
    .catch(function(err) {
      console.log(err.stack);
      res.send('Error fetching items from ' + req.params.collection);
    })
  ;
})

//food get
app.param(":id", function(req, res, next, collection) {
    req.collection = db.get(collection, {safe: true});
    next();
});

app.get('/food/foodget', function(req, res, next) {
    req.collection.find({}, {
        limit: 20
    }).then (function(docs) {
        res.send(docs);
    })
    .catch(function(err) {
        console.log(err.stack);
        res.send('Error fetching items from' + req.params.collection);
    })
    ;
})


//food autocomplete
router.post(
    "/food/autocomplete",
    [
      check("suggestion", "Enter any suggestion"),
    ],
    async (req, res) => {
      const errors = validationResult(req);
  
  
      const { suggestion } = req.body;
      try {
        let food = await Food.findOne({
          suggestion
        });
        if (!food)
          return res.status(400).json({
            message: ""
          });
  
        
        jwt.sign(
          payload,
          "randomString",
          {
            expiresIn: 3600
          },
          (err, token) => {
            if (err) throw err;
            res.status(200).json({
              token
            });
          }
        );
      } catch (e) {
        console.error(e);
        res.status(500).json({
          message: "Server Error"
        });
      }
    }
  );


  //food brands
router.post(
    "/food/brands",
    [
      check("foodbrands", "Enter any food brands"),
    ],
    async (req, res) => {
      const errors = validationResult(req);
  
  
      const { foodbrands } = req.body;
      try {
        let food = await Food.findOne({
          foodbrands
        });
        if (!food)
          return res.status(400).json({
            message: ""
          });
  
        
        jwt.sign(
          payload,
          "randomString",
          {
            expiresIn: 3600
          },
          (err, token) => {
            if (err) throw err;
            res.status(200).json({
              token
            });
          }
        );
      } catch (e) {
        console.error(e);
        res.status(500).json({
          message: "Server Error"
        });
      }
    }
  );


    //food categories
router.post(
    "/food/categories",
    [
      check("foodcategories", "Enter food categories"),
    ],
    async (req, res) => {
      const errors = validationResult(req);
  
  
      const { foodcategories } = req.body;
      try {
        let food = await Food.findOne({
          foodcategories
        });
        if (!food)
          return res.status(400).json({
            message: ""
          });
  
        
        jwt.sign(
          payload,
          "randomString",
          {
            expiresIn: 3600
          },
          (err, token) => {
            if (err) throw err;
            res.status(200).json({
              token
            });
          }
        );
      } catch (e) {
        console.error(e);
        res.status(500).json({
          message: "Server Error"
        });
      }
    }
  );


    //food sub categories
router.post(
    "/food/subcategories",
    [
      check("foodsubcategories", "Enter food categories"),
    ],
    async (req, res) => {
      const errors = validationResult(req);
  
  
      const { foodsubcategories } = req.body;
      try {
        let food = await Food.findOne({
          foodsubcategories
        });
        if (!food)
          return res.status(400).json({
            message: ""
          });
  
        
        jwt.sign(
          payload,
          "randomString",
          {
            expiresIn: 3600
          },
          (err, token) => {
            if (err) throw err;
            res.status(200).json({
              token
            });
          }
        );
      } catch (e) {
        console.error(e);
        res.status(500).json({
          message: "Server Error"
        });
      }
    }
  );

//GET BACK ALL THE FOOD 
router.get('/foodsearch', async  (req, res) => {
  try{
      const food = await foodsearch.find();
      res.json(foodsearch);
  } catch (err) {
    res.json({ message:err});
  }
});

//SUBMIT A FOOD
router.post('/',async (req, res) => {
    const foodsearch = new foodsearch ({
      food_id: req.body.food_id,
      food_name: req.body.food_name,
      food_type: req.body.food_type,
      brand_name: req.body.brand_name,
      food_url: req.body.food_url,
      food_description: req.body.food_description
    });
    try {
        const foodsearch = await foodsearch.save();
        res.json(foodsearch);
    } catch (err) {
      res.json({ message : err });
    }

});

//SPECIFIC FOOD
router.get('/:postId', async (req, res) => {
  try {
    const post = await foodsearch.findById(req.params.postId);
    res.json(post);
  } catch (err) {
    res.json({ message : err}) ;
  }
});

//DELETE FOOD
router.delete('/:foodId', async (req, res) => {
  try {
   const removedfoodsearch = await foodsearch.remove({ _id: req.params.postId});
   res.json(removedfoodsearch);
  } catch (err) {
    res.json({message : err});
  }

});
module.exports = router;