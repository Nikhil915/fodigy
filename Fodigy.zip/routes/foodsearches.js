const express = require('express')
const router = express.Router()
const Foodsearch = require('../model/foodsearch')


router.get('/', async(req,res) => {
    try{
           const foodsearches = await Foodsearch.find()
           res.json(foodsearches)
    }catch(err){
        res.send('Error ' + err)
    }
})

router.get('/:id', async(req,res) => {
    try{
           const foodsearches = await Foodsearch.findById(req.params.id)
           res.json(foodsearches)
    }catch(err){
        res.send('Error ' + err)
    }
})


router.post('/', async(req,res) => {
    const foodsearches = new Foodsearch({
        food_id: req.body.food_id,
        food_name: req.body.food_name,
        food_type: req.body.food_type,
        brand_name: req.body.brand_name,
        food_url: req.body.food_url,
        food_description: req.body.food_description
    })

    try{
        const a1 =  await foodsearches.save() 
        res.json(a1)
    }catch(err){
        res.send('Error')
    }
})

router.patch('/:id',async(req,res)=> {
    try{
        const foodsearches = await Foodsearch.findById(req.params.id) 
        foodsearches.sub = req.body.sub
        const a1 = await foodsearches.save()
        res.json(a1)   
    }catch(err){
        res.send('Error')
    }

})

module.exports = router