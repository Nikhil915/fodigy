const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const user = require("./routes/user"); //new addition
const food = require("./routes/food");
const foodgets = require("./routes/foodgets");
const morgan = require("morgan");
const InitiateMongoServer = require("./config/db");
//const fatAPI = new require('fatsecret')(KEY, SECRET);

// Initiate Mongo Server
InitiateMongoServer();

const app = express();


// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json())
    .use(morgan());
//morgan for request in terminal
   

// PORT
const PORT = process.env.PORT || 4000;

const router = express.Router();

//Import Routes
const foodRoute = require('./routes/food');
app.use('/food', foodRoute);

const foodsearchRouter = require('./routes/foodsearches');
app.use('/foodsearches', foodsearchRouter);

const foodgetRouter = require('./routes/foodgets');
const foodget = require("./model/foodget");
app.use('/foodgets', foodgetRouter);

const dietRouter = require('./routes/diet');
const dietplans = require("./model/dietplans");
const { post } = require("./routes/user");
app.use('/dietplans', dietRouter);

app.get("/dietplans", async (req, res) => {
  try {
    const dietplan = await dietplans.find({})
    res.send(dietplan)
  } catch (error) {
    res.status(500)
  }
});

app.post("/dietplans", async (req, res) => {
  try {
    const diet = new Diet();
    post.title = req.body.title;
    post.plan_type = req.body.plan_type;
    await Diet.save();
    res.send(diet)
  } catch (error) {
    res.send(500)
  }
});

app.get("/dietplans/:dietId", async (req, res) => {
  try {
    const diet = await Diet.findOne({
      _id: req.params.dietId
    });
    res.send(dietplans)
  } catch (error) {
    res.send(500);
  }
});

app.put("/dietplans/:dietId", async (req, res) => {
  try {
    const diet = await Diet.findByIdAndUpdate({
      _id: req.params.dietId
    }, req.body, {
      new: true,       //true use for send update in pm when we request.
      runValidators: true  //use for all value in model schemas.
    });
    res.send(dietplan)
  } catch (error) {
    res.send(500);
  }
});

app.delete("/dietplans/:dietId", async (req, res) => {
  try {
    const diet = await Diet.findByIdAndRemove({
      _id: req.params.dietId
    });
    res.send(dietplan)
  } catch (error) {
    res.send(500)
  }
})


/**
 * Router Middleware
 * Router - /user/*
 * Method - *
 */
app.use("/user", user);
app.use("/food", food);
app.use("/foodgets", foodgets);
app.use("/dietplans", dietplans);



app.listen(PORT, (req, res) => {
  console.log(`Server Started at PORT ${PORT}`);
});