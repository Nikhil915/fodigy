const mongoose = require("mongoose");

var FoodlogsSchema =  mongoose.Schema({
    id : {
        type : String,
        required : "Required"
    },
    log_date : {
        type : String,
        required : "Required"
    },
    food_id : {
        type : String,
    },
    food_time : {
        type : String,
    },
    food_type : {
        type : String,
    },
    log_time : {
        type : String,
    },
    energy : {
        type : String,
    },
    protein : {
        type : String,
    },
    carbohydrate : {
        type : String,
    },
    lipid_fat : {
        type : String,
    },
    item_unit : {
        type : String,
    },
    item_quantity : {
        type : String,
    },
    servings : {
        type : String,
    },
    created_by : {
        type : String,
    },
    updated_by : {
        type : String,
    },
    deleted_by : {
        type : String,
    },
    is_active : {
        type : String,
    },
    is_deleted : {
        type : String,
    },
    created_on : {
        type : String,
    },
    updated_on : {
        type : String,
    },
    deleted_on : {
        type : String,
    },
});

module.exports = mongoose.model("Foodlogs",FoodlogsSchema);