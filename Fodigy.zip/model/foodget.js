const mongoose = require("mongoose");

const FoodgetSchema = new mongoose.Schema({
    food_id: {
        type: String,
        required: true
    },
    food_name: {
        type: String,
        required: true
    },
    food_type: {
        type: String,
        required: true
    },
    brand_name: {
        type: String,
        required: true
    },
    food_url: {
        type: String,
        required: true
    },
    serving_id: {
        type: String,
        required: true
    },
    serving_description: {
        type: String,
        required: true
    },
    serving_url: {
        type: String,
        required: true
    },
    metric_serving_amount: {
        type: String,
        required: true
    },
    metric_serving_unit: {
        type: String,
        required: true
    },
    number_of_units: {
        type: String,
        required: true
    },
    measurement_description: {
        type: String,
        required: true
    },
    calories: {
        type: String,
        required: true
    },
    carbohydrate: {
        type: String,
        required: true
    },
    protein: {
        type: String,
        required: true
    },
    fat: {
        type: String,
        required: true
    },
    saturated_fat: {
        type: String,
        required: true
    },
    polyunsaturated_fat: {
        type: String,
        required: true
    },
    monounsaturated_fat: {
        type: String,
        required: true
    },
    trans_fat: {
        type: String,
        required: true
    },
    cholesterol: {
        type: String,
        required: true
    },
    sodium: {
        type: String,
        required: true
    },
    potassium: {
        type: String,
        required: true
    },
    fiber: {
        type: String,
        required: true
    },
    sugar: {
        type: String,
        required: true
    },
    vitamin_a: {
        type: String,
        required: true
    },
    vitamin_c: {
        type: String,
        required: true
    },
    calcium: {
        type: String,
        required: true
    },
    iron : {
        type: String,
        required: true
    }

})

module.exports = mongoose.model("Foodget",FoodgetSchema);