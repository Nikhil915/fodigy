const mongoose = require("mongoose");

const FavourfooditemSchema = new mongoose.Schema({
    id : {
        type : String,
        required : "Required"
    },
    user_id : {
        type : String,
        required : "Required"
    },
    food_item_id : {
        type : String,
    },
});

module.exports = mongoose.model("Favouritefooditems",FavourfooditemSchema);