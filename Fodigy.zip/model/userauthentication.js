const mongoose = require("mongoose");

const UserauthenticationSchema = mongoose.Schema({
    id: {
        type: String,
        required: true
    },
    userId: {
        type: String,
        required: true
    },
    osType: {
        type: String,
        required: true
    },
    fcmId: {
        type: String,
        required: true
    },
    createdOn: {
        type: String,
        required: true
    },
    secureToken: {
        type: String,
        required: true
    },
})

module.exports = mongoose.model("Userauthentication",UserauthenticationSchema);