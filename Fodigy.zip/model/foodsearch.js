const mongoose = require("mongoose");

const FoodsearchSchema = mongoose.Schema({
    food_id: {
        type: String,
        required: true
    },
    food_name: {
        type: String,
        required: true
    },
    food_type: {
        type: String,
        required: true
    },
    brand_name: {
        type: String,
        required: true
    },
    food_url: {
        type: String,
        required: true
    },
    food_description: {
        type: String,
        required: true
    }
})

module.exports = mongoose.model("Foodsearch",FoodsearchSchema);