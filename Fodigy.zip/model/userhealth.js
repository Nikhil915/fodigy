const mongoose = require("mongoose");

const UserhealthSchema = mongoose.Schema({
    id: {
        type: String,
        required: true
    },
    for_date: {
        type: String,
        required: true
    },
    active_energy: {
        type: String,
        required: true
    },
    resting_energy: {
        type: String,
        required: true
    },
    steps: {
        type: String,
        required: true
    },
    walking_distance: {
        type: String,
        required: true
    },
    highest_heart_beat: {
        type: String,
        required: true
    },
    lowest_heart_beat: {
        type: String,
        required: true
    },
    created_by: {
        type: String,
        required: true
    },
    created_on: {
        type: String,
        required: true
    },
})

module.exports = mongoose.model("Userhealth",UserhealthSchema);