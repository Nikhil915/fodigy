const mongoose = require("mongoose");

const UserheightchangesSchema = mongoose.Schema({
    user_id: {
        type: String,
        required: true
    },
    user_height: {
        type: String,
        required: true
    },
    changed_on: {
        type: String,
        required: true
    },
})

module.exports = mongoose.model("Userheightchanges",UserheightchangesSchema);