const mongoose = require("mongoose");

const DietSchema = new mongoose.Schema({
    id : {
        type : String,
        required : "Required"
    },
    title : {
        type : String,
        required : "Required"
    },
    plan_type : {
        type : String,
    },
    energy_required_for_man : {
        type : String,
    },
    energy_required_for_women : {
        type : String,
    },
    energy_burn_goal : {
        type : String,
    },
    description : {
        type : String,
    },
    protein : {
        type : String,
    },
    carbohydrate : {
        type : String,
    },
    fat : {
        type : String,
    },
    created_by : {
        type : String,
    },
    updated_by : {
        type : String,
    },
    deleted_by : {
        type : String,
    },
    is_active : {
        type : String,
    },
    is_deleted : {
        type : String,
    },
    created_on : {
        type : String,
    },
    updated_on : {
        type : String,
    },
    deleted_on : {
        type : String,
    },
},
 {
    timestamps: true,
}
);

module.exports = mongoose.model("Dietplans",DietSchema);