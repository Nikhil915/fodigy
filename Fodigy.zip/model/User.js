const mongoose = require("mongoose");

const UserSchema = mongoose.Schema({
  username: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now()
  }
});


/** 
//------ Relational DB----------//
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
 //CREATE SCHEMA AND MODEL
 const BookSchema  = new Schema({
   title: String,
   pages: Number
 });

 const AuthorSchema  = new Schema({
  name: String,
  age: Number,
  books: [BookSchema]
});

const Author = mongoose.model('author', AuthorSchema);
module.exports = Mariochar;             //mariochar: filename
*/

// export model user with UserSchema
module.exports = mongoose.model("user", UserSchema);
