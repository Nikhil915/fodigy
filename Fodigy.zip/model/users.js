const mongoose = require("mongoose");

const UsersSchema = mongoose.Schema({
    id: {
        type: String,
        required: true
    },
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        required: true
    },
    gender: {
        type: String,
        required: true
    },
    phoneNumber: {
        type: String,
        required: true
    },
    emailId: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    dob: {
        type: String,
        required: true
    },
    initWeight: {
        type: String,
        required: true
    },
    userHeight: {
        type: String,
        required: true
    },
    userWeight: {
        type: String,
        required: true
    },
    targetWeight: {
        type: String,
        required: true
    },
    dietPlan: {
        type: String,
        required: true
    },
    frequently_exercise: {
        type: String,
        required: true
    },
    facebookId: {
        type: String,
        required: true
    },
    googleId: {
        type: String,
        required: true
    },
    instagramId: {
        type: String,
        required: true
    },
    appleId: {
        type: String,
        required: true
    },
    profileImage: {
        type: String,
        required: true
    },
    imageBy: {
        type: String,
        required: true
    },
    user_points: {
        type: String,
        required: true
    },
    isActive: {
        type: String,
        required: true
    },
    isDeleted: {
        type: String,
        required: true
    },
    createdOn: {
        type: String,
        required: true
    },
    updatedOn: {
        type: String,
        required: true
    },
    deletedOn: {
        type: String,
        required: true
    },
    userLocation: {
        type: String,
        required: true
    },
    isProfileCompleted: {
        type: String,
        required: true
    },
    osType: {
        type: String,
        required: true
    },
    forgotToken: {
        type: String,
        required: true
    },
})

module.exports = mongoose.model("users",UsersSchema);