const mongoose = require("mongoose");

const NotificationsSchema = mongoose.Schema({
    Id: {
        type: String,
        required: true
    },
    User_Id: {
        type: String,
        required: true
    },
    Type: {
        type: String,
        required: true
    },
    Title: {
        type: String,
        required: true
    },
    Notification: {
        type: String,
        required: true
    },
    Send_Date: {
        type: String,
        required: true
    },
    isOpen: {
        type: String,
        required: true
    },
    Food_time: {
        type: String,
        required: true
    },
})

module.exports = mongoose.model("Notifications",NotificationsSchema);