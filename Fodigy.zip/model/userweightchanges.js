const mongoose = require("mongoose");

const UserweightchangesSchema = mongoose.Schema({
    user_id: {
        type: String,
        required: true
    },
    user_weight: {
        type: String,
        required: true
    },
    changed_on: {
        type: String,
        required: true
    },
})

module.exports = mongoose.model("Userweightchanges",UserweightchangesSchema);