const mongoose = require("mongoose");

const SettingsSchema = mongoose.Schema({
    id: {
        type: String,
        required: true
    },
    group_name: {
        type: String,
        required: true
    },
    setting_title: {
        type: String,
        required: true
    },
    setting_key: {
        type: String,
        required: true
    },
    setting_value: {
        type: String,
        required: true
    },
})

module.exports = mongoose.model("Settings",SettingsSchema);