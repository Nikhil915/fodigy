const mongoose = require("mongoose");

const WaterloghistorySchema = mongoose.Schema({
    id: {
        type: String,
        required: true
    },
    user_id: {
        type: String,
        required: true
    },
    log_date: {
        type: String,
        required: true
    },
    total_glass: {
        type: String,
        required: true
    },
    water_goal: {
        type: String,
        required: true
    },
    created_by: {
        type: String,
        required: true
    },
    updated_by: {
        type: String,
        required: true
    },
    deleted_by: {
        type: String,
        required: true
    },
    is_active: {
        type: String,
        required: true
    },
    is_deleted: {
        type: String,
        required: true
    },
    created_on: {
        type: String,
        required: true
    },
    updated_on: {
        type: String,
        required: true
    },
    deleted_on: {
        type: String,
        required: true
    },
})

module.exports = mongoose.model("Waterloghistory",WaterloghistorySchema);