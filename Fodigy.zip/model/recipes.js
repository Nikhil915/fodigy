const mongoose = require("mongoose");

const RecipesSchema = mongoose.Schema({
    id: {
        type: String,
        required: true
    },
    recipe_name: {
        type: String,
        required: true
    },
    recipe_slug: {
        type: String,
        required: true
    },
    num_of_serving: {
        type: String,
        required: true
    },
    serving_size: {
        type: String,
        required: true
    },
    item_unit: {
        type: String,
        required: true
    },
    recipe_weight: {
        type: String,
        required: true
    },
    recipe_type_id: {
        type: String,
        required: true
    },
    recipe_notes: {
        type: String,
        required: true
    },
    prepare_time: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    total_carbohydrate: {
        type: String,
        required: true
    },
    total_protein: {
        type: String,
        required: true
    },
    total_energy: {
        type: String,
        required: true
    },
    total_lipid_fat: {
        type: String,
        required: true
    },
    recipe_image: {
        type: String,
        required: true
    },
    eqv: {
        type: String,
        required: true
    },
    food_type: {
        type: String,
        required: true
    },
    is_public: {
        type: String,
        required: true
    },
    created_by: {
        type: String,
        required: true
    },
    updated_by: {
        type: String,
        required: true
    },
    deleted_by: {
        type: String,
        required: true
    },
    is_active: {
        type: String,
        required: true
    },
    is_deleted: {
        type: String,
        required: true
    },
    created_on: {
        type: String,
        required: true
    },
    updated_on: {
        type: String,
        required: true
    },
    deleted_on: {
        type: String,
        required: true
    },
})

module.exports = mongoose.model("Recipes",RecipesSchema);