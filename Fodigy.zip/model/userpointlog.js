const mongoose = require("mongoose");

const UserpointlogSchema = mongoose.Schema({
    id: {
        type: String,
        required: true
    },
    user_id: {
        type: String,
        required: true
    },
    event_date: {
        type: String,
        required: true
    },
    event_type: {
        type: String,
        required: true
    },
    points_earned: {
        type: String,
        required: true
    },
    setting_title: {
        type: String,
        required: true
    },
    event_time: {
        type: String,
        required: true
    },
    is_redeemed: {
        type: String,
        required: true
    },
    created_on: {
        type: String,
        required: true
    },
})

module.exports = mongoose.model("Userpointlog",UserpointlogSchema);