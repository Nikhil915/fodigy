const mongoose = require("mongoose");

var FooditemsSchema =  mongoose.Schema({
    id : {
        type : String,
        required : "Required"
    },
    food_id : {
        type : String,
        required : "Required"
    },
    food_name : {
        type : String,
    },
    brand_name : {
        type : String,
    },
    food_description : {
        type : String,
    },
    food_type : {
        type : String,
    },
    food_url : {
        type : String,
    },
    unit : {
        type : String,
    },
    qty : {
        type : String,
    },
    food_image : {
        type : String,
    },
    nutrients : {
        type : String,
    },
    servings : {
        type : String,
    },
    is_active : {
        type : String,
    },
});

module.exports = mongoose.model("Fooditems",FooditemsSchema);